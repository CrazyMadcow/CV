"""Render selected figure regions from the applicant's interview PDF.

Usage: python extract-interview-figures.py --source PATH_TO_INTERVIEW_PDF
Coordinates are PDF points. These are direct crops, with no retouching.
Requires PyMuPDF; the source PDF is intentionally not included in this package.
"""

import argparse
from pathlib import Path

import pymupdf


FIGURES = (
    (6, (543, 280, 819, 437), "interview-delay-flight.png"),
    (14, (575, 171, 810, 245), "interview-pipe-hils.png"),
    (29, (36, 204, 464, 446), "interview-wildfire-interface.png"),
    (8, (46, 178, 357, 355), "interview-hoverbike-prototype.png"),
    (28, (348, 177, 604, 330), "interview-hoverbike-system.png"),
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path)
    args = parser.parse_args()
    output_dir = Path(__file__).resolve().parents[1] / "assets" / "img"
    output_dir.mkdir(parents=True, exist_ok=True)
    with pymupdf.open(args.source) as document:
        if len(document) < 29:
            raise ValueError("Expected the 35-page interview presentation PDF.")
        for number, coordinates, name in FIGURES:
            page = document[number - 1]
            clip = pymupdf.Rect(coordinates)
            if not page.rect.contains(clip):
                raise ValueError(f"Crop is outside page {number}: {clip}")
            page.get_pixmap(matrix=pymupdf.Matrix(3, 3), clip=clip, alpha=False).save(output_dir / name)
            print(f"Page {number}: {name}")


if __name__ == "__main__":
    main()
